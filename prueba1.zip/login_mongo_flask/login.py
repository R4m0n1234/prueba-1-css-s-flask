from flask import Flask, render_template, url_for, request, session, redirect
from flask_pymongo import PyMongo
import bcrypt
from flask_uploads import UploadSet, configure_uploads, IMAGES
app = Flask(__name__)
photos = UploadSet('photos', IMAGES)


app.config['UPLOADED_PHOTOS_DEST'] = 'static/img'
configure_uploads(app, photos)

app.config['MONGO_DBNAME'] = 'users'
app.config['MONGO_URI'] = 'mongodb://localhost:27017/users'

mongo = PyMongo(app)

@app.route('/signup')
def signup():
    return render_template('register.html')

@app.route('/')
def index():
    if 'username' in session:
        ##return 'You are logged in as ' + session['username']
        return redirect(url_for('user_info'))

    return render_template('index.html')

@app.route("/user_info")
def user_info():
    users = mongo.db.webpage_users
    login_user = users.find_one({"name":session["username"]})
    email=login_user["email"]
    interest=login_user["interest"]
    user_profile_picture=login_user["profile_pic"]
    return render_template("user_main.html", email=email,interest=interest,profile_picture=user_profile_picture)

@app.route('/login', methods=['POST'])
def login():
    users = mongo.db.webpage_users
    login_user = users.find_one({'name' : request.form['username']})

    if login_user:
        if bcrypt.hashpw(request.form['pass'].encode("utf-8"),login_user['password'])== login_user['password']:
            session['username'] = request.form['username']
            return redirect(url_for('user_info'))

    return 'Invalid username/password combination'

@app.route('/register', methods=['POST', 'GET'])
def register():

    if request.method == 'POST':
        users = mongo.db.webpage_users
        existing_user = users.find_one({'name' : request.form['username']})

        if existing_user is None:
            if request.form["pass"]==request.form["confirm_pass"]:
                hashpass = bcrypt.hashpw(request.form['pass'].encode('utf-8'), bcrypt.gensalt())

                if request.method == 'POST' and 'photo' in request.files:
                    #photo_name=
                    filename = photos.save(request.files['photo'])

                users.insert({'name' : request.form['username'], 'password' : hashpass,"email":request.form["email"],"interest":request.form["interest"],"profile_pic":filename})
                session['username'] = request.form['username']


                return redirect(url_for('user_info'))
            else:
                return "no coincide tu password"

        return 'That username already exists!'

    return render_template('register.html')


@app.route("/show")
def show():
    users=mongo.db.webpage_users
    k=""
    for x in users.find():
        k=k+str(x)
    return k

@app.route("/logout")
def logout():
    session['logged_in'] = False
    return render_template('index.html')


@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST' and 'photo' in request.files:
        filename = photos.save(request.files['photo'])
        return filename
    return render_template('uploads.html')

if __name__ == '__main__':
    app.secret_key = 'mysecret'
    app.run(debug=True,host="127.0.0.1")
